#version 120
#define AETHER_NETHER
#include "/program/gbuffers_basic.vsh"
